<?php 
/** www.yunlu99.com QQ:270656184 **/

header('location:admin.php');
