<?php 

echo '﻿';
$mod='blank';
$title = 'PUBG平哥流控™后台管理';
include('head.php');
include('nav.php');
if($_GET['a'] == 'qset'){
include('qset.php');
}else{
;echo '<div class="box">
';
$my=isset($_GET['my'])?$_GET['my']:null;
if($my=='del'){
echo '<div class="panel panel-default">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
$user=$_GET['user'];
$sql=db(_openvpn_)->where(array(_iuser_=>$user))->delete();
if($sql){
db('top')->where(['username'=>$user])->delete();
echo '删除成功！';
}
else{
echo '删除失败！';
}
echo '<hr/><a href="./user_list.php">>>返回账号列表</a></div></div>';
}
else
{
echo '<form action="user_list.php" method="get" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="支持模糊搜索" value="'.$_GET['kw'].'">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>&nbsp;';
if(!empty($_GET['kw'])) {
$numrows = db(_openvpn_)->where(_iuser_.' LIKE :kw',[':kw'=>'%'.$_GET['kw'].'%'])->getnums();
$where = _iuser_.' LIKE :kw';
$data = [':kw'=>'%'.$_GET['kw'].'%'];
$con='<a href="#" class="btn btn-default">平台共有 <b>'.$numrows.'</b> 个账号</a>';
}else{
$numrows = db(_openvpn_)->where()->getnums();
$where= '';
$con='<a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个账号</a>';
}
echo $con;
echo '&nbsp;<button type="button" class="btn btn-success" onclick="javascript:var n = prompt(\'统一新增流量，减少请输入负数（单位：G）\');if(!n){return false;}else{addLlAll(n)}">统一新增流量</button>';
echo '&nbsp;<button type="button" class="btn btn-warning" onclick="javascript:var n = prompt(\'统一新增天数，减少请输入负数（单位：天）\');if(!n){return false;}else{addTimeAll(n)}">统一新增天数</button>';
echo '&nbsp;<button type="button" class="btn btn-danger" onclick="if(!confirm(\'清理全部禁用用户？执行后不可恢复！\')){return false;}else{delAllJ()}">清理全部禁用用户</button>';
echo '</form>';
;echo '
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr>
		  <th width="50">序号</th>
		  <th>账号</th>
		  <th>添加时间</th>
		  <th>到期时间</th>
		  <th>剩余流量</th>
		  <th>总流量</th>
		  <th>属性</th>
		  <th>状态</th>
		  <th>操作</th>
		  </tr></thead>
          <tbody>
';
$rs = db(_openvpn_)->where($where,$data)->fpage($_GET['page'],30)->order('id DESC')->select();
$i = 1;
foreach($rs as $res)
{
if(date('Y-m-d',$res['starttime']) == date('Y-m-d',time())){
$p = '&nbsp;<span class="label label-success">今日新增</span>';
}elseif(date('Y-m-d',$res['starttime']) == date('Y-m-d',(time()-24*60*60))){
$p = '&nbsp;<span class="label label-warning">昨日新增</span>';
}else{
$p ='';
}
if($_GET['act'] == 'del'){
$db = db('openvpn');
if($db->where(array('id'=>$_POST['id']))->delete()){
die(json_encode(array('status'=>'success')));
}else{
die(json_encode(array('status'=>'error')));
}
}elseif($_GET['act'] == 'i'){
$i = $_POST['i'] == '1'?'1': '0';
$db = db('openvpn');
if($db->where(array('id'=>$_POST['id']))->update(array('i'=>$i))){
die(json_encode(array('status'=>'success')));
}else{
die(json_encode(array('status'=>'error')));
}
}else
if($res['vip'] == 1){
$vip = '&nbsp;<span class="label label-success">VIP</span>';
}elseif($res['vip'] == 2){
$vip = '&nbsp;<span class="label label-warning">VIP2</span>';
}else{
$vip ='';
}
;echo '<tr class="line-id-';echo $res['iuser'];echo '">
<td>';echo $i;echo '</td>
<td>';echo $vip;echo '';echo $res['iuser'];echo '';echo $p;echo '</td>
<td>';echo date('Y-m-d',$res['starttime']);echo '</td>
<td>';echo date('Y-m-d',$res['endtime']);echo '</td>
<td><span class="shengyu">';echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);echo '</span>MB</td>
<td><span class="maxll">';echo round(($res['maxll'])/1024/1024);echo '</span>MB</td>
<td>';echo ($res['daili']?'<span class="label label-warning">代理用户</span>':'<span class="label label-success">普通用户</span>');echo '</td>
<td>';echo ($res['i']?'<span class="label label-info">开通</span>':'<span class="label label-danger">禁用</span>');echo '</td>
<td>
<a class="btn btn-default" href="./user_list.php?a=qset&user=';echo $res['iuser'];echo '">配置</a>&nbsp;
<a href="javascript:void(0)" class="btn btn-danger" onclick="if(!confirm(\'你确实要删除此记录吗？\')){return false;}else{delLine(\'';echo $res['iuser'];echo '\')}">删除</a>&nbsp;
<a href="javascript:void(0)" class="btn btn-primary" onclick="javascript:var n = prompt(\'请输入您要重置的流量（单位：G)\');if(!n){return false;}else{addLl(\'';echo $res['id'];echo '\',n)}">重置流量</a>
</td>
</tr>

';
$i++;
}
;echo '          </tbody>
        </table>
    </div>
';
}
;echo '   
 </div>
<script>
function addLlAll(n){
		var url = \'./option.php?my=addllAll\';
		$.post(url,{
			"n":n
		  },function(){
			
		});
		//var m = $(\'.line-id-\'+id+" .maxll");
		//var ne = n*1024;
		//m.html(ne);
		location.reload();
}

function qiyong(id){
	var doc = $(\'.line-id-\'+id+\' .showstatus\');
	if(doc.attr(\'data\') == "1"){
		doc.html("已禁用").attr({\'data\':\'0\'});
	}else{
		doc.html("已启用").attr({\'data\':\'1\'});
	}
	var url = "user_list.php?act=i";
		var data = {
			"id":id,
			"i":doc.attr(\'data\')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}

function addTimeAll(n){
		var url = \'./option.php?my=addtimeAll\';
		$.post(url,{
			"n":n
		  },function(){
			
		});
	
		location.reload();
}

function addLl(id,n){
		var url = \'./option.php?my=addll\';
		$.post(url,{
			"n":n,
			"user":id
		  },function(){
			location.reload();
		});
}
function delAllJ(){
		var url = \'./option.php?my=deljy\';
		$.post(url,{
		  },function(){
			location.reload();
		});
}
</script>
';
echo create_page_html($numrows,$_GET['page']);
}
include('footer.php');
