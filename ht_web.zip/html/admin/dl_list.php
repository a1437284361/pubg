<?php 

echo '﻿';
$mod='blank';
$title = 'PUBG平哥流控™后台管理';
include('head.php');
include('nav.php');
$key = file_get_contents('/root/res/app_key.txt');
;echo '<div class="" >
<div class="box">
';
if($_GET['act']=='del'){
if(db('app_daili')->where(array('id'=>$_GET['id']))->delete()){
tip_success('操作成功！',$_SERVER['HTTP_REFERER']);
}else{
tip_failed('十分抱歉修改失败',$_SERVER['HTTP_REFERER']);
}
}
else
{
echo '<form action="?" method="get" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="账号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>&nbsp;';
if(!empty($_GET['kw'])) {
$numrows = db('app_daili')->where(array('name'=>$_GET['kw']))->getnums();
$where = array('name'=>$_GET['kw']);
$con='<a href="#" class="btn btn-success">平台共有 <b>'.$numrows.'</b> 个账号</a>';
}else{
$numrows = db('app_daili')->where()->getnums();
$where= '';
$con='<a href="#" class="btn btn-success">平台共有 <b>'.$numrows.'</b> 个账号</a>';
}
echo $con;
echo '</form>';
;echo '      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th width="50">序号</th><th>账号</th><th>添加时间</th><th>到期时间</th><th>等级</th><th>余额</th><th>APP_KEY</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
';
$rs=db('app_daili')->where($where)->fpage($_GET['page'],30)->order('id DESC')->select();
$i = 1;
foreach($rs as $res)
{
$deng=db('app_daili_type')->where(['id'=>$res['type']])->find();
if(date('Y-m-d',$res['time']) == date('Y-m-d',time())){
$p = '&nbsp;<span class="label label-success">今日新增</span>';
}elseif(date('Y-m-d',$res['time']) == date('Y-m-d',(time()-24*60*60))){
$p = '&nbsp;<span class="label label-warning">昨日新增</span>';
}else{
$p ='';
}
;echo '	<tr class="line-id-';echo $res['id'];echo '">
	<td>';echo $i;echo '</td>
	<td>';echo $vip;echo '';echo $res['name'];echo '';echo $p;echo '</td>
	<td>';echo date('Y-m-d',$res['time']);echo '</td>
	<td>';echo date('Y-m-d',$res['endtime']);echo '</td>
	<td>';echo $deng['name'];echo ' 折扣：';echo $deng['per'];echo '%</td>
	<td><span class="maxll">';echo $res['balance'];echo '元</td>
	<td>';echo trim($key).'_'.$res['id'];;echo '</td>
	<td>';echo ($res['lock']?'<span class="label label-info">开通</span>':'<span class="label label-danger">禁用</span>');echo '</td>
	<td>
<!--  &nbsp;<a class="btn btn-xs btn-success" href="dluser_list.php?act=mod&id=';echo $res['id'];echo '">用户</a>
	  &nbsp;<a class="btn btn-xs btn-warning" href="dlkm_list.php?act=mod&id=';echo $res['id'];echo '">卡密</a>   -->
	&nbsp;<a class="btn btn-default" href="dl_adds.php?act=mod&id=';echo $res['id'];echo '">配置</a>
	&nbsp;<a href="?act=del&id=';echo $res['id'];echo '" class="btn btn-danger" onclick="if(!confirm(\'你确实要删除此记录吗？\')){return false;}else{return true}">删除</a>
	</td>
	</tr>

';
$i++;
}
;echo '          </tbody>
        </table>
    </div>
    </div>
';echo create_page_html($numrows,$_GET['page']);;echo '';}include('footer.php');